# Architecture Design — Wrist2Whats

Top-level components:
[Garmin Watch] -> [Companion iOS] -> [Backend (FastAPI)] -> [Playwright Web Automation] -> [WhatsApp Recipient]
                              |
                          [Postgres DB]
                              |
                          [Admin UI]

Deployment:
- VPS (Ubuntu 22.04) with Docker Compose:
  - services: api (FastAPI), postgres, redis (optional), play_sender (Playwright headful), nginx (reverse proxy + TLS)
- storage: persistent volume for Playwright storage_state (whatsapp session)
- monitoring: health endpoints, logs, optional Prometheus exporter
