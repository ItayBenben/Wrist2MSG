# SRS — Wrist2Whats

## 1. מבוא
מטרה: לאפשר שליחת הודעה מה-Garmin Vivoactive 5 ל-WhatsApp של נמענים, ללא התערבות ידנית בטלפון, באמצעות שרת אוטומציה ששומר session ב-WhatsApp Web.

## 2. רכיבים
- Watch App (Monkey C)
- Companion iOS (Swift)
- Backend (FastAPI, Python)
- Playwright sender (Python)
- Postgres DB
- Admin UI (option)

## 3. דרישות פונקציונליות (מובלטות)
F01 — UI בשעון: בורר איש קשר ובורר תבנית הודעה + כפתור Send.
F02 — Companion מאמת payload ושולח ל־/api/v1/send.
F03 — Backend queue + Playwright שולח הודעה דרך WhatsApp Web.
F04 — Audit log לכל שליחה.
F05 — Rate limiting & retry.

## 4. דרישות לא פונקציונליות
- זמינות: 99.5% (VPS)
- פרטיות: DB encryption at rest, TLS בכל התעבורה
- ביצועים: lat < 5s typical
- תאימות: iOS 16+, Garmin Vivoactive 5 (Connect IQ)

## 5. מגבלות וסיכונים
- שימוש ב-WhatsApp Web automation עלול להפר תנאי שימוש של WhatsApp. יש לנקוט במשנה זהירות ולהגביל קצב ושליחת הודעות בודדות בלבד.
