# Low Level Design

## API Summary (OpenAPI excerpt)
POST /api/v1/send
Request:
{
  "user_id": "uuid",
  "recipient_id": 1,
  "template_id": 2,
  "custom_text": "optional override"
}
Response: 202 Accepted { "job_id": "uuid" }

## DB (core tables)
- users (id, username, api_key)
- recipients (id, user_id, name, phone)
- templates (id, user_id, title, body)
- jobs (id, user_id, recipient_id, template_id, status, attempts, last_error)
- audit_logs (id, job_id, event_time, event_type, payload)

## PlaywrightService (Python)
- send_whatsapp(phone: str, text: str) -> dict
- load_session()
- save_session()
- refresh_qr_if_needed()
- robust selectors + retries
