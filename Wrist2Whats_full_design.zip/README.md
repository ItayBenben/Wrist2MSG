# Wrist2Whats

מערכת לשליחת הודעות WhatsApp מתוך Garmin Watch (Vivoactive 5) ללא התערבות ידנית בטלפון.

מבנה הפרויקט:
- docs/ — מסמכי אפיון, דיאגרמות PlantUML, SRS, Architecture
- src/watch/ — קבצי Monkey C (placeholder)
- src/iphone_companion/ — Swift companion (placeholder)
- src/server/ — backend Python (FastAPI) + Playwright skeleton

הוראות להפעלה:
1. חלץ את תוכן ה-ZIP לתיקייה של ה-repo שלך או לקו-סביבת פיתוח.
2. קרא את `docs/` לכל המסמכים והוראות הפריסה.
3. ב-srv תמצא Skeleton של FastAPI ו-Playwright; יש להתאים secrets ו-ENV לפני הרצה.

Branch for this commit: feature/system-design
