# iPhone Companion (Swift) - placeholder

This folder should contain the iOS companion app project that integrates with Garmin Connect Mobile SDK.
Responsibilities:
- receive payload from Watch
- verify signature (HMAC)
- hold JWT/API key in Keychain
- POST to backend /api/v1/send
