# Watch app (Monkey C) - placeholder

This folder should contain the Garmin Connect IQ Monkey C project:
- App.mc (entry)
- resources/ (images, locales)
- modules/CommManager.mc

Payload example (JSON):
{
  "user_id": "UUID",
  "recipient_id": 3,
  "template_id": 1,
  "timestamp": 1690000000,
  "signature": "HMAC_SHA256"
}
