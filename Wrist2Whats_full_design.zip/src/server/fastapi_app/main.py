from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel
import uuid
app = FastAPI(title="Wrist2Whats API (skeleton)")

class SendRequest(BaseModel):
    user_id: str
    recipient_id: int
    template_id: int
    custom_text: str | None = None

def fake_auth():
    # placeholder for real auth dependency
    return {"id": "user-123"}

@app.post("/api/v1/send", status_code=202)
async def send_msg(req: SendRequest, user = Depends(fake_auth)):
    job_id = str(uuid.uuid4())
    # TODO: insert job into DB and push to queue
    return {"job_id": job_id, "status": "queued"}
