from playwright.sync_api import sync_playwright
import time, urllib.parse, os

STORAGE_STATE = os.environ.get("PLAYWRIGHT_STATE", "whatsapp_storage.json")

def send_whatsapp(phone: str, text: str, headful=True) -> dict:
    text_enc = urllib.parse.quote(text)
    url = f"https://web.whatsapp.com/send?phone={phone}&text={text_enc}"
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=not headful)
        context = None
        if os.path.exists(STORAGE_STATE):
            context = browser.new_context(storage_state=STORAGE_STATE)
        else:
            context = browser.new_context()
        page = context.new_page()
        page.goto(url)
        try:
            page.wait_for_selector("div[contenteditable='true']", timeout=15000)
            page.keyboard.press("Enter")
            time.sleep(2)
            context.storage_state(path=STORAGE_STATE)
            return {"status":"sent"}
        except Exception as e:
            return {"status":"failed", "error": str(e)}
        finally:
            context.close()
            browser.close()
