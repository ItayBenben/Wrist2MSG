#!/usr/bin/env bash
# Helper script: creates branch feature/system-design, adds files and pushes.
set -e
BRANCH="feature/system-design"
git checkout -b $BRANCH || git switch $BRANCH
git add .
git commit -m "Add full system design & skeleton"
git push -u origin $BRANCH
echo "Branch pushed: $BRANCH"
